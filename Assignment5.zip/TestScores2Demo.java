public class TestScores2Demo {
    public static void main(String[] args) {
        double[] scores = {95, 82, 101};   // 101 should trigger exception

        try {
            TestScores2 ts = new TestScores2(scores);
            System.out.println("Average = " + ts.getAverage());
        } catch (InvalidTestScore e) {
            System.out.println("Caught InvalidTestScore: " + e.getMessage());
        }
    }
}
