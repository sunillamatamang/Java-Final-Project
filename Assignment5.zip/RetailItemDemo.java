public class RetailItemDemo {
    public static void main(String[] args) {
        try {
            RetailItem item1 = new RetailItem("Jacket", 10, 59.99);
            System.out.println(item1);

            // This will cause NegativePriceException
            RetailItem item2 = new RetailItem("Shoes", 5, -20.00);
            System.out.println(item2);

        } catch (NegativeUnitsOnHandException | NegativePriceException ex) {
            System.out.println("Exception caught: " + ex.getMessage());
        }

        try {
            // This will cause NegativeUnitsOnHandException
            RetailItem item3 = new RetailItem("Hat", -3, 15.00);
            System.out.println(item3);

        } catch (NegativeUnitsOnHandException | NegativePriceException ex) {
            System.out.println("Exception caught: " + ex.getMessage());
        }
    }
}
