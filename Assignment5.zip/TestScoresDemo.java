public class TestScoresDemo {
    public static void main(String[] args) {
        double[] goodScores = {90, 85, 100, 75};

        TestScores ts1 = new TestScores(goodScores);
        System.out.println("Average = " + ts1.getAverage());

        double[] badScores = {90, -5, 88};

        try {
            TestScores ts2 = new TestScores(badScores);
            System.out.println("Average = " + ts2.getAverage());
        } catch (IllegalArgumentException ex) {
            System.out.println("Exception caught: " + ex.getMessage());
        }
    }
}
