public class CustomerDemo {
    public static void main(String[] args) {
        Customer c = new Customer(
                "Jane Doe",
                "123 Main St, Austin, TX",
                "512-555-1234",
                1001,
                true
        );

        System.out.println(c);
    }
}
