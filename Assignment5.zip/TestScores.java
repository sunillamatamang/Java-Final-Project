public class TestScores {

    private double[] scores;

    public TestScores(double[] scores) {
        // Defensive copy (optional but good practice)
        this.scores = new double[scores.length];
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] < 0 || scores[i] > 100) {
                throw new IllegalArgumentException(
                        "Invalid test score: " + scores[i]);
            }
            this.scores[i] = scores[i];
        }
    }

    public double getAverage() {
        double total = 0.0;
        for (double s : scores) {
            total += s;
        }
        return total / scores.length;
    }
}
