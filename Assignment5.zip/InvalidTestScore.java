public class InvalidTestScore extends Exception {

    public InvalidTestScore(double score) {
        super("Invalid test score: " + score);
    }

    public InvalidTestScore(String message) {
        super(message);
    }
}
