public class PreferredCustomer extends Customer {
    private double purchases;     // cumulative purchases
    private double discountLevel; // 0.05, 0.06, 0.07, 0.10, etc.

    public PreferredCustomer() {
        super();
    }

    public PreferredCustomer(String name, String address, String telephoneNumber,
                             int customerNumber, boolean onMailingList,
                             double purchases) {
        super(name, address, telephoneNumber, customerNumber, onMailingList);
        setPurchases(purchases);
    }

    public void setPurchases(double purchases) {
        this.purchases = purchases;
        updateDiscountLevel();
    }

    public double getPurchases() {
        return purchases;
    }

    public double getDiscountLevel() {
        return discountLevel;
    }

    // Determine discount based on purchases
    private void updateDiscountLevel() {
        if (purchases >= 2000.0)
            discountLevel = 0.10;
        else if (purchases >= 1500.0)
            discountLevel = 0.07;
        else if (purchases >= 1000.0)
            discountLevel = 0.06;
        else if (purchases >= 500.0)
            discountLevel = 0.05;
        else
            discountLevel = 0.0;
    }

    @Override
    public String toString() {
        return super.toString() +
               "\nTotal Purchases: $" + purchases +
               "\nDiscount Level: " + (discountLevel * 100) + "%";
    }
}
