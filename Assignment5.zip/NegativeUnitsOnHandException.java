public class NegativeUnitsOnHandException extends Exception {
    public NegativeUnitsOnHandException(int units) {
        super("Negative units on hand not allowed: " + units);
    }
}
