public class PreferredCustomerDemo {
    public static void main(String[] args) {
        PreferredCustomer pc = new PreferredCustomer(
                "John Smith",
                "456 Oak Ave, Austin, TX",
                "512-555-9876",
                2001,
                true,
                1750.0
        );

        System.out.println(pc);
    }
}
