public class NegativePriceException extends Exception {
    public NegativePriceException(double price) {
        super("Negative price not allowed: " + price);
    }
}
