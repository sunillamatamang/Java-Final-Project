public class RegularStudent extends Student {

    public RegularStudent(String id, String name) {
        super(id, name);
    }

    @Override
    public double getAverageGrade() {
        // Regular students: normal average
        return getAverageGradeRaw();
    }
}
