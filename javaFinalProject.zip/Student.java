import java.util.ArrayList;
import java.util.List;

public abstract class Student {
    private String id;
    private String name;
    private List<Subject> subjects;

    public Student(String id, String name) {
        this.id = id;
        this.name = name;
        this.subjects = new ArrayList<>();
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<Subject> getSubjects() {
        return subjects;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void addOrUpdateSubject(String subjectName, double grade) {
        // Update if exists
        for (Subject s : subjects) {
            if (s.getName().equalsIgnoreCase(subjectName)) {
                s.setGrade(grade);
                return;
            }
        }
        // Otherwise add new subject
        subjects.add(new Subject(subjectName, grade));
    }

    public Subject getSubjectByName(String subjectName) {
        for (Subject s : subjects) {
            if (s.getName().equalsIgnoreCase(subjectName)) {
                return s;
            }
        }
        return null;
    }

    public boolean removeSubject(String subjectName) {
        Subject target = null;
        for (Subject s : subjects) {
            if (s.getName().equalsIgnoreCase(subjectName)) {
                target = s;
                break;
            }
        }
        if (target != null) {
            subjects.remove(target);
            return true;
        }
        return false;
    }

    public double getAverageGradeRaw() {
        if (subjects.isEmpty()) {
            return 0.0;
        }
        double sum = 0.0;
        for (Subject s : subjects) {
            sum += s.getGrade();
        }
        return sum / subjects.size();
    }

    // Polymorphic method: subclasses can override this
    public abstract double getAverageGrade();

    // For saving to file
    public String subjectsToDataString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < subjects.size(); i++) {
            Subject s = subjects.get(i);
            sb.append(s.getName()).append(",").append(s.getGrade());
            if (i < subjects.size() - 1) {
                sb.append(";");
            }
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ID: ").append(id)
          .append(", Name: ").append(name)
          .append(", Type: ").append(this.getClass().getSimpleName())
          .append("\nSubjects: ");

        if (subjects.isEmpty()) {
            sb.append("No subjects yet.");
        } else {
            for (Subject s : subjects) {
                sb.append("\n  ").append(s.toString());
            }
        }
        sb.append("\nAverage: ").append(getAverageGrade());
        return sb.toString();
    }
}
