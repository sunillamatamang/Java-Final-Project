public class HonorsStudent extends Student {

    public HonorsStudent(String id, String name) {
        super(id, name);
    }

    @Override
    public double getAverageGrade() {
        // Honors students: small bonus (demonstrates polymorphism)
        double avg = getAverageGradeRaw();
        double bonus = avg * 0.05; // 5% bonus
        double result = avg + bonus;
        if (result > 100.0) {
            result = 100.0;
        }
        return result;
    }
}
