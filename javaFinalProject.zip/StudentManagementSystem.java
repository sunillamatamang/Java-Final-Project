import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class StudentManagementSystem {

    private List<Student> students;
    private Scanner scanner;

    public StudentManagementSystem() {
        students = new ArrayList<>();
        scanner = new Scanner(System.in);
    }

    public static void main(String[] args) {
        StudentManagementSystem sms = new StudentManagementSystem();
        sms.run();
    }

    public void run() {
        boolean exit = false;
        while (!exit) {
            printMenu();
            int choice = readInt("Enter your choice: ");
            switch (choice) {
                case 1:
                    addStudentMenu();
                    break;
                case 2:
                    removeStudent();
                    break;
                case 3:
                    updateStudentMenu();
                    break;
                case 4:
                    viewStudentDetails();
                    break;
                case 5:
                    addOrUpdateGrade();
                    break;
                case 6:
                    generateReportsMenu();
                    break;
                case 7:
                    saveToFileMenu();
                    break;
                case 8:
                    loadFromFileMenu();
                    break;
                case 9:
                    listAllStudents();
                    break;
                case 0:
                    System.out.println("Exiting program. Goodbye!");
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            System.out.println();
        }
    }

    private void printMenu() {
        System.out.println("===== Student Management System =====");
        System.out.println("1. Add student");
        System.out.println("2. Remove student");
        System.out.println("3. Update student name");
        System.out.println("4. View student details");
        System.out.println("5. Add/Update grade for a student");
        System.out.println("6. Generate reports");
        System.out.println("7. Save data to file");
        System.out.println("8. Load data from file");
        System.out.println("9. List all students");
        System.out.println("0. Exit");
    }

    private int readInt(String message) {
        while (true) {
            try {
                System.out.print(message);
                int value = Integer.parseInt(scanner.nextLine());
                return value;
            } catch (NumberFormatException e) {
                System.out.println("Invalid number. Please try again.");
            }
        }
    }

    private double readDouble(String message) {
        while (true) {
            try {
                System.out.print(message);
                double value = Double.parseDouble(scanner.nextLine());
                return value;
            } catch (NumberFormatException e) {
                System.out.println("Invalid decimal number. Please try again.");
            }
        }
    }

    private void addStudentMenu() {
        System.out.println("=== Add Student ===");
        System.out.print("Enter student ID: ");
        String id = scanner.nextLine().trim();

        if (findStudentById(id) != null) {
            System.out.println("Student with this ID already exists.");
            return;
        }

        System.out.print("Enter student name: ");
        String name = scanner.nextLine().trim();

        System.out.println("Select student type:");
        System.out.println("1. Regular Student");
        System.out.println("2. Honors Student");
        int typeChoice = readInt("Choice: ");

        Student s;
        if (typeChoice == 2) {
            s = new HonorsStudent(id, name);
        } else {
            s = new RegularStudent(id, name);
        }

        students.add(s);
        System.out.println("Student added successfully.");
    }

    private void removeStudent() {
        System.out.println("=== Remove Student ===");
        System.out.print("Enter student ID: ");
        String id = scanner.nextLine().trim();
        Student s = findStudentById(id);
        if (s == null) {
            System.out.println("Student not found.");
        } else {
            students.remove(s);
            System.out.println("Student removed successfully.");
        }
    }

    private void updateStudentMenu() {
        System.out.println("=== Update Student Name ===");
        System.out.print("Enter student ID: ");
        String id = scanner.nextLine().trim();
        Student s = findStudentById(id);
        if (s == null) {
            System.out.println("Student not found.");
            return;
        }
        System.out.println("Current name: " + s.getName());
        System.out.print("Enter new name: ");
        String newName = scanner.nextLine().trim();
        s.setName(newName);
        System.out.println("Student name updated.");
    }

    private void viewStudentDetails() {
        System.out.println("=== View Student Details ===");
        System.out.print("Enter student ID: ");
        String id = scanner.nextLine().trim();
        Student s = findStudentById(id);
        if (s == null) {
            System.out.println("Student not found.");
        } else {
            System.out.println(s.toString());
        }
    }

    private void addOrUpdateGrade() {
        System.out.println("=== Add/Update Grade ===");
        System.out.print("Enter student ID: ");
        String id = scanner.nextLine().trim();
        Student s = findStudentById(id);
        if (s == null) {
            System.out.println("Student not found.");
            return;
        }

        System.out.print("Enter subject name: ");
        String subjectName = scanner.nextLine().trim();

        double grade;
        while (true) {
            grade = readDouble("Enter grade (0 - 100): ");
            if (grade < 0 || grade > 100) {
                System.out.println("Grade must be between 0 and 100.");
            } else {
                break;
            }
        }

        s.addOrUpdateSubject(subjectName, grade);
        System.out.println("Grade saved.");
    }

    private void generateReportsMenu() {
        boolean back = false;
        while (!back) {
            System.out.println("=== Reports Menu ===");
            System.out.println("1. Average grade for each student");
            System.out.println("2. Highest and lowest grade for a specific subject");
            System.out.println("3. List students sorted by overall average grade");
            System.out.println("0. Back to main menu");
            int choice = readInt("Enter your choice: ");
            switch (choice) {
                case 1:
                    reportAverageGradePerStudent();
                    break;
                case 2:
                    reportHighestLowestForSubject();
                    break;
                case 3:
                    reportStudentsSortedByAverage();
                    break;
                case 0:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
            System.out.println();
        }
    }

    private void reportAverageGradePerStudent() {
        System.out.println("=== Average Grade for Each Student ===");
        if (students.isEmpty()) {
            System.out.println("No students in the system.");
            return;
        }
        for (Student s : students) {
            System.out.println("ID: " + s.getId() +
                               ", Name: " + s.getName() +
                               ", Type: " + s.getClass().getSimpleName() +
                               ", Average: " + s.getAverageGrade());
        }
    }

    private void reportHighestLowestForSubject() {
        System.out.println("=== Highest and Lowest Grades for a Subject ===");
        System.out.print("Enter subject name: ");
        String subjectName = scanner.nextLine().trim();

        boolean foundAny = false;
        double highest = Double.NEGATIVE_INFINITY;
        double lowest = Double.POSITIVE_INFINITY;
        Student highestStudent = null;
        Student lowestStudent = null;

        for (Student s : students) {
            Subject subj = s.getSubjectByName(subjectName);
            if (subj != null) {
                foundAny = true;
                double grade = subj.getGrade();
                if (grade > highest) {
                    highest = grade;
                    highestStudent = s;
                }
                if (grade < lowest) {
                    lowest = grade;
                    lowestStudent = s;
                }
            }
        }

        if (!foundAny) {
            System.out.println("No grades found for this subject.");
        } else {
            System.out.println("Subject: " + subjectName);
            System.out.println("Highest: " + highest + " (Student ID: " +
                               highestStudent.getId() + ", Name: " +
                               highestStudent.getName() + ")");
            System.out.println("Lowest: " + lowest + " (Student ID: " +
                               lowestStudent.getId() + ", Name: " +
                               lowestStudent.getName() + ")");
        }
    }

    private void reportStudentsSortedByAverage() {
        System.out.println("=== Students Sorted by Average Grade (High to Low) ===");
        if (students.isEmpty()) {
            System.out.println("No students in the system.");
            return;
        }

        List<Student> sorted = new ArrayList<>(students);
        sorted.sort(new Comparator<Student>() {
            @Override
            public int compare(Student o1, Student o2) {
                double diff = o2.getAverageGrade() - o1.getAverageGrade();
                if (diff > 0) {
                    return 1;
                } else if (diff < 0) {
                    return -1;
                } else {
                    return 0;
                }
            }
        });

        for (Student s : sorted) {
            System.out.println("ID: " + s.getId() +
                               ", Name: " + s.getName() +
                               ", Average: " + s.getAverageGrade());
        }
    }

    private void saveToFileMenu() {
        System.out.println("=== Save Data to File ===");
        System.out.print("Enter file name (e.g., students.txt): ");
        String fileName = scanner.nextLine().trim();
        saveToFile(fileName);
    }

    private void loadFromFileMenu() {
        System.out.println("=== Load Data from File ===");
        System.out.print("Enter file name (e.g., students.txt): ");
        String fileName = scanner.nextLine().trim();
        loadFromFile(fileName);
    }

    private void saveToFile(String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (Student s : students) {
                String type;
                if (s instanceof HonorsStudent) {
                    type = "Honors";
                } else {
                    type = "Regular";
                }
                String line = type + "|" + s.getId() + "|" + s.getName()
                              + "|" + s.subjectsToDataString();
                writer.write(line);
                writer.newLine();
            }
            System.out.println("Data saved to file successfully.");
        } catch (IOException e) {
            System.out.println("Error while saving to file: " + e.getMessage());
        }
    }

    private void loadFromFile(String fileName) {
        List<Student> loadedStudents = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Format: TYPE|ID|NAME|subject1,grade1;subject2,grade2;...
                String[] parts = line.split("\\|");
                if (parts.length < 3) {
                    continue; // skip invalid lines
                }
                String type = parts[0];
                String id = parts[1];
                String name = parts[2];

                Student s;
                if ("Honors".equalsIgnoreCase(type)) {
                    s = new HonorsStudent(id, name);
                } else {
                    s = new RegularStudent(id, name);
                }

                if (parts.length == 4 && !parts[3].trim().isEmpty()) {
                    String subjectsData = parts[3];
                    String[] subjectTokens = subjectsData.split(";");
                    for (String token : subjectTokens) {
                        String[] pair = token.split(",");
                        if (pair.length == 2) {
                            String subjectName = pair[0];
                            try {
                                double grade = Double.parseDouble(pair[1]);
                                s.addOrUpdateSubject(subjectName, grade);
                            } catch (NumberFormatException e) {
                                // skip invalid grade
                            }
                        }
                    }
                }
                loadedStudents.add(s);
            }
            // Replace current list if load succeeded
            students = loadedStudents;
            System.out.println("Data loaded from file successfully.");
        } catch (IOException e) {
            System.out.println("Error while loading from file: " + e.getMessage());
        }
    }

    private Student findStudentById(String id) {
        for (Student s : students) {
            if (s.getId().equalsIgnoreCase(id)) {
                return s;
            }
        }
        return null;
    }

    private void listAllStudents() {
        System.out.println("=== List of All Students ===");
        if (students.isEmpty()) {
            System.out.println("No students in the system.");
            return;
        }
        for (Student s : students) {
            System.out.println("ID: " + s.getId() +
                               ", Name: " + s.getName() +
                               ", Type: " + s.getClass().getSimpleName());
        }
    }
}
